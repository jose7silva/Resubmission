﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace resubmission
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();

            // Subscribe to button click events
            btnAddRecipe.Click += AddRecipe_Click;
            btnDisplayRecipes.Click += DisplayRecipes_Click;
            btnViewRecipe.Click += ViewRecipe_Click;
            btnClearRecipe.Click += ClearRecipe_Click;
            btnExit.Click += Exit_Click;
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipePage addRecipePage = new AddRecipePage(recipes); // Pass the recipes list
            addRecipePage.ShowDialog();
        }

        private void DisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            //DisplayRecipePage displayRecipesPage = new DisplayRecipePage(recipes);
            //displayRecipesPage.ShowDialog();
            ViewRecipePage viewRecipePage = new ViewRecipePage(recipes);
            viewRecipePage.ShowDialog();
        }

        private void ViewRecipe_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipePage displayRecipesPage = new DisplayRecipePage(recipes);
            displayRecipesPage.ShowDialog();
            //ViewRecipePage viewRecipePage = new ViewRecipePage(recipes);
            //viewRecipePage.ShowDialog();
            
        }

        private void ClearRecipe_Click(object sender, RoutedEventArgs e)
        {
            ClearRecipe clearRecipe = new ClearRecipe(recipes);
            clearRecipe.ShowDialog();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }

}
