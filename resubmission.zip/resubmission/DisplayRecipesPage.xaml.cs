﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace resubmission
{
    public partial class DisplayRecipePage : Window
    {
        private List<Recipe> recipes;
        private List<Recipe> displayedRecipes;

        public DisplayRecipePage(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            displayedRecipes = recipes.ToList();

            DisplayRecipes();
        }

        private void DisplayRecipes()
        {
            lstSearchResults.ItemsSource = displayedRecipes.Select(recipe => recipe.Name);
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = txtSearch.Text;
            displayedRecipes = recipes
                .Where(recipe => recipe.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();

            DisplayRecipes();
        }

        private void LstSearchResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int selectedIndex = lstSearchResults.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Recipe selectedRecipe = displayedRecipes[selectedIndex];
                txtRecipeDetails.Text = selectedRecipe.Name;
            }
            else
            {
                txtRecipeDetails.Clear(); // Clear the text when no recipe is selected
            }
        }
    }

}
