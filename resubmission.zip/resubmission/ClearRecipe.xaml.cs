﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace resubmission
{
    public partial class ClearRecipe : Window
    {
        private List<Recipe> recipes;
        private List<Recipe> displayedRecipes;

        public ClearRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            displayedRecipes = recipes.ToList();

            DisplayRecipes();
        }

      
        private void DisplayRecipes()
        {
            // Set the ListBox to display only the recipe names
            lstSearchResults.ItemsSource = displayedRecipes.Select(recipe => recipe.Name);
        }


        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = txtSearch.Text;
            displayedRecipes = recipes
                .FindAll(recipe => recipe.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);

            DisplayRecipes();
        }

        private void LstSearchResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int selectedIndex = lstSearchResults.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Recipe selectedRecipe = displayedRecipes[selectedIndex];
                txtRecipeDetails.Text = GetRecipeDetails(selectedRecipe);
            }
            else
            {
                txtRecipeDetails.Clear();
            }
        }

       private string GetRecipeDetails(Recipe recipe)
{
    string details = $"Recipe: {recipe.Name}\n\nIngredients:\n";
    foreach (Ingredient ingredient in recipe.Ingredients)
    {
        details += $"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}\n";
    }

    details += "\nSteps:\n";
    for (int i = 0; i < recipe.Steps.Count; i++)
    {
        details += $"{i + 1}. {recipe.Steps[i]}\n";
    }

    return details;
}


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            int selectedIndex = lstSearchResults.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Recipe selectedRecipe = displayedRecipes[selectedIndex];
                displayedRecipes.RemoveAt(selectedIndex);
                recipes.Remove(selectedRecipe);
                DisplayRecipes();
                txtRecipeDetails.Clear(); // Clear recipe details after deletion
            }
            else
            {
                MessageBox.Show("Please select a recipe to delete.");
            }
        }
    }
}
