﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace resubmission
{
    public partial class AddRecipePage : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        private Recipe currentRecipe;

        public AddRecipePage()
        {
            InitializeComponent();
            currentRecipe = new Recipe("");
        }

        public AddRecipePage(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            currentRecipe = new Recipe(""); // Initialize currentRecipe here too
        }

        private void BtnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = txtIngredientName.Text;
            double quantity = Convert.ToDouble(txtIngredientQuantity.Text);
            string unit = txtIngredientUnit.Text;
            double calories = Convert.ToDouble(txtIngredientCalories.Text);
            string foodGroup = txtIngredientFoodGroup.Text;

            currentRecipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);

            txtIngredientName.Clear();
            txtIngredientQuantity.Clear();
            txtIngredientUnit.Clear();
            txtIngredientCalories.Clear();
            txtIngredientFoodGroup.Clear();
        }

        private void BtnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text;
            currentRecipe.Name = recipeName;

            string stepsText = txtSteps.Text;
            string[] stepsArray = stepsText.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            foreach (string step in stepsArray)
            {
                currentRecipe.AddStep(step);
            }

            recipes.Add(currentRecipe);

            MessageBox.Show("Recipe added successfully!");

            ClearFields();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ClearFields()
        {
            txtRecipeName.Clear();
            txtSteps.Clear();
            txtIngredientName.Clear();
            txtIngredientQuantity.Clear();
            txtIngredientUnit.Clear();
            txtIngredientCalories.Clear();
            txtIngredientFoodGroup.Clear();
            currentRecipe = new Recipe("");
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; } // Make sure this property is present
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        // Constructor
        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }


    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void AddIngredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void Display()
        {
            Console.WriteLine($"\nRecipe: {Name}");

            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }
}
