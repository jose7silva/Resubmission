﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace resubmission
{
    public partial class ViewRecipePage : Window
    {
        private List<Recipe> recipes;

        public ViewRecipePage(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            // Populate ListBox with recipe names
            foreach (Recipe recipe in recipes)
            {
                lstRecipes.Items.Add(recipe.Name);
            }
        }

        private void LstRecipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int selectedIndex = lstRecipes.SelectedIndex;
            if (selectedIndex >= 0)
            {
                Recipe selectedRecipe = recipes[selectedIndex];
                txtRecipeDetails.Text = GetRecipeDetails(selectedRecipe);
            }
        }

        private string GetRecipeDetails(Recipe recipe)
        {
            string details = $"Recipe: {recipe.Name}\n\nIngredients:\n";
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                details += $"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}\n";
            }

            details += "\nSteps:\n";
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                details += $"{i + 1}. {recipe.Steps[i]}\n";
            }

            return details;
        }

    }
}
